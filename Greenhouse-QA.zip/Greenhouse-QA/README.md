Various bits and pieces used by QA for the care and feeding of the Greenhouse project.

## backendRegressionTests
Postman collections used to tests the backend APIs

## createProductsAndStories
Postman collection to create products and stories for a test environment using the `greenhouseproducts.json` and `greenhousestories.json` data files. Because Postman collections only support running with one data file, `createProductsAndStories.sh` script starts a web server to serve the files to Postman and runs the collection.

## jmeter
Basic script for generating load against backend APIs

## mobileApps
Coming soon

## website
Coming soon

## authoringTool
Coming soon