#!/bin/sh

if [ $# == 0 ] ; then
  echo "Please provide environment (dev or stage)"
  exit 0
fi

ENV=$1

#Start web server
python -mSimpleHTTPServer 9898 &
PID=$!
sleep 5

#Run Postman collection
newman run "Create Products and Stories.postman_collection.json" -e ../greenhouse-$ENV.postman_environment.json --insecure

#Stop web server
kill -9 $PID


